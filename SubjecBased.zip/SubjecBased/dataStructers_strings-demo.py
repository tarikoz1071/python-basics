from textwrap import wrap


website = 'http://www.sadikturan.com'
course = 'Python Kursu: Bastan Sona Python Programlama Rehberiniz (40 saat)'

# 1- 'course' karakter dizsinde kac karakter bulunmaktadir?
# -------------------------------------------------------------length = len(course)
result = len(course)
length = len(website)
length2 = len(course)

# 2- 'website' icinden www karakterlerini alin.
#--------------------------------------------------------------length2 = len(website)
result = website[7:10]

# 3- 'website' icinden com karakterlerini alin.
result = website[22:25]
result = website[length-3:length]

# 4- 'course' icinden ilk 15 ve son 15 karakterlerini alin.
result = course[0:15]
result = course[:15]
result = course[-15:]

# 5- 'course' ifadesindeki karakterleri tersten yazdirin.
result = course[::-1]
result = course[length2::-1]

                                                                # s = '12345' * 5
                                                                # print(s[::5])

name, surname, age, job, = 'Bora', 'Yilmaz', 33, 'muhendis'

# 6- Yukarida verilen degiskenler ile ekrana asagidaki ifadeyi yazdirin.
#     'Benim adim Bora Yilmaz, Yasim 32 ve meslegim muhendis.'
result = 'Benim adim ' + name + ' ' + surname + ', Yasim ' + str(age) + ' ve meslegim ' + job
result = 'Benim adim {} {}, Yasim {} ve meslegim {}.'.format(name,surname,age,job)
result = 'Benim adim {0} {1}, Yasim {2} ve meslegim {3}.'.format(name,surname,age,job)
result = 'Benim adim {1} {0}, Yasim {2} ve meslegim {3}.'.format(name,surname,age,job)
result = f'Benim adim {name} {surname}, Yasim {age} ve meslegim {job}'

# 7- 'Hello World ifadesindeki w harfini 'W' ile degistirin.
s = 'Hello World'
s = s[0:6] + 'W' + s[-4:]
s.replace('w','W')
print (s)


# 8- 'abc' ifadesini yan yana 3 defa yazdirin.
result = 'abc ' * 3

print(result)
