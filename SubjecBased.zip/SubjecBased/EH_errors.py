# Error                             docs.python.ort/3/library/exceptions.html
# print (a) => NameError
# int('1a2') => ValueError
# print('denem'e) => SyntaxError
# print(10/0) => ZeroDivisionError

