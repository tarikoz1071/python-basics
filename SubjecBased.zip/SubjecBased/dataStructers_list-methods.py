numbers = [3, 11, 5, 7, 17, 13, 71, 77]
letters = ['y', 'b', 'c', 'z', 'x', 'k', 't', 'f', 't']

val = min(numbers)
val = max(numbers)
val = min(letters)
val = max(letters)

val = numbers[3:6]
val = numbers[:3]
val = numbers[4:]

numbers[1] = 33
# numbers.append('51')
# numbers.append('55')
# numbers.insert(1, 69)
# numbers.insert(-1, 99)

# numbers.pop()
# numbers.pop(0)
# numbers.pop(-1)
# numbers.remove(13)

numbers.sort()
numbers.reverse()
letters.sort()
letters.reverse()

print(numbers)
print(letters)

print(len(numbers))
print(len(letters))

print(numbers.count(3))
print(letters.count('t'))
# print(val)

numbers.clear()
print(numbers)
