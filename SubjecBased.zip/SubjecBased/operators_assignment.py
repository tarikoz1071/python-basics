# x = 5
# y = 10
# z = 20

# x, y, z = 5, 16, 20
# x, y = y, x 

# x += 5          # x = x + 5
# x -= 5          # x = x - 5
# x *= 5          # x = x * 5
# x /= 5          # x = x / 5
# x %= 5          # x = x % 5
# y //= 5          # y = y // 5
# y **= z          # y = y ** z


values = 1, 2, 3, 4, 5        # atanacak degisken sayisindan fazla ya da az olamaz

print(values)
print(type(values))

x, *y, z = values

print(x, y, z)