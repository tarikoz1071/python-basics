list = [1, 2, 3]
tuple = (1, 'iki', 3)

print(type(list))
print(type(tuple))

# print(list[2])
# print(tuple[2])

# print(len(tuple))
# print(len(list))

list = ['ali', 'veli']
tuple = ('sani', 'kamil', 'mehmet', 'mehmet' )
names = ('kerim', 'osman', 'mehmet' ) + tuple 

list[0] = 'ahmet'
# tuple[0] = 'semih'

print(tuple.count('mehmet'))
print(tuple.index('mehmet'))

print(names)

print(list)
print(tuple)