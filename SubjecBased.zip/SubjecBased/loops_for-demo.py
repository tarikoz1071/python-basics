# 1- Sayilar listesindeki hangi sayilar 3'un katidir?
sayilar = [1,3,5,7,9,12,19,21]
listthree = []
for a in sayilar:
    if a % 3 == 0: 
        listthree.append(a)
        print(f"sayi \"{a}\" --> 'listthree' listesine eklenmistir.")
    else: pass
print (listthree)
# 2- Sayilar listesinde sayilarin toplami kactir?
toplam = 0
for b in sayilar:
    toplam = toplam + b
print (toplam)
# 3- Sayilar listesindeki tek sayilarin karesini aliniz?
tekkaredict = {}
for c in sayilar:
    if c % 2 == 1:
        d = c**2
        tekkaredict.update({f'{c}':d})
    else: pass
print(tekkaredict)
for keys,values in tekkaredict.items():
    print(keys,values,sep=' - ')
    pass



# 4- Sehirlerden hangileri en fazla 5 karakterlidir?
sehirler = ['kocaeli', 'istanbul', 'ankara', 'izmir', 'rize']
azkrktrsehirler = []
for i in sehirler:
    if len(i) <= 5:
        print(f'{i} --> "azkrktrsehirler" listesine eklenmistir.')
        azkrktrsehirler.append(i)
    else: pass
print(azkrktrsehirler)



# 5- Urunlerin fiyatlari toplamni nedir?
# 6- Urunlerden fiyati en fazla 5000 olan urunleri gosteriniz? 
urunler = [
    {'name':'samsung s6', 'price': '3000'},
    {'name':'samsung s7', 'price': '4000'},    
    {'name':'samsung s8', 'price': '5000'},
    {'name':'samsung s9', 'price': '6000'},
    {'name':'samsung s10', 'price': '7000'}
]
totalprice = 0
for x in urunler:
    print(x)
    # print(x['name'],'-', x['price'])
    totalprice = totalprice + int(x['price'])
    if int(x['price']) <= 5000:
        print (f"{x['name']} isimli urunun fiyati {int(x['price'])} tl dir.")
print(f'Total price is: {totalprice} tl')









