mylist = [1,2,3]
myString = 'my string'

print(len(mylist))
print(len(myString))
print(type(mylist))
print(type(myString))

class Theatre():
    def __init__(self, plot, characters, theme):
        self.plot = plot
        self.characters = characters
        self.theme = theme
        print('theatre objesi olusturuldu.')

t = Theatre('anlatim', 'karakterler', 'theme')

print(type(t))
print(len(t))
