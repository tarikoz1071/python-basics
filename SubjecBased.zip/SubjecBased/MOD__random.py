
import random           # Dosya ismi modul ile ayni isimde olmamalidir.
# result = dir(random)
# result = help(random)
result = random.random()       # 0.0-1.0 arasinda rastgele sayi uretir.
result1 = random.random()*100       
result2 = random.uniform(10,100)        # Belirtilen aralik arasinda sayi uretir     
result3 = int(random.uniform(10,100))
result4 = random.randint(100,1000)      # Belirtilen aralik arasinda "tam" sayi uretir
print(result)
print(result1)
print(result2)
print(result3)
print(result4)


kucukkoy = ['abdurrahim','kenan','yucel','yildiran','edip',
'enes','mehmetfurkan','furkanozel','vahdettin','saadettin','bekir',
'umit','nurullah','nazir','recai','salih','salihKuzu','cengiz',
'erkan','nadir','murat','cetin','yavuz','unal','ufuk','temel']
x=0
while x < 11:
    # result5 = kucukkoy[random.randint(0,len(kucukkoy)-1)]
    result5 = random.choice(kucukkoy)
    print(f'{result5}', end = ' - ')
    x += 1
print('\n')
y=0
while y < 11:
    result6 = random.sample(kucukkoy,2)
    print(f'{result6}', end = '  ')
    y += 1
print()



liste = list(range((21)))
result7 = liste
random.shuffle(liste)       # Karistirma islemi yapar.
print('\n',result7,'\n')
result8 = random.sample(liste, 3)       # Listeden rastgele eleman alir.
print(result8)
