# "r": (Read) okuma. Varsayılan mod olup, Dosya konumda yoksa hata verir.
file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile2.txt", "x", encoding = 'utf-8')
file.close()
try:
    file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile2.txt","r")
except FileNotFoundError:
    print("Dosya okuma hatasi")
file.close()




#-------------for dongusu ile dosya okuma-------------
file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile.txt", "r", encoding = 'utf-8')
for i in file:
    print(i, end="")
file.close()




#-------------read() fonksiyonu-------------
file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile.txt", "r", encoding = 'utf-8')
content1 = file.read()
print("icerik 1")
print(content1)
content2 = file.read()
print("icerik 2")
print(content2)
file.close()

content = file.read(5)
content = file.read(3)
content = file.read(3)



#-------------readline() fonksiyonu-------------
print(file.readline(),end='')
print(file.readline(),end='')
print(file.readline(),end='')
print(file.readline(),end='')
file.close()




#-------------readlines() fonksiyonu-------------
liste = file.readlines()
print(liste)
print(liste[0])
print(liste[1])
print(liste[2])
file.close()






