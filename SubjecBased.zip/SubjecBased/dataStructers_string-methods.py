message = 'Hello There. My name is Taha Ozdogan'

# message = message.upper()
# message = message.lower()
# message = message.title()
# message = message.capitalize()
# message = message.strip()
# message = message.split()
# message = message.split('.')
# message = '---'.join(message)


# index = message.find('Taha')
# isFound = message.startswith('H')
# isFound = message.endswith('n')

# message = message.replace('Taha','Tarik')
# message = message.replace('ç','c')
#                  .replace('ö','o')
#                  .replace(' ','-')

message = message.center(50,'*')

print(message)
