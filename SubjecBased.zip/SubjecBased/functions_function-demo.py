# 1- Gonderilen bir kelimeyi belirtilen kez ekranda gosteren fonksiyonu yazin.
from operator import indexOf


def yazdir(kelime, adet):
    print (f'{kelime} - '*(adet-1) + f'{kelime}')               #-- ST method modified
yazdir('merhaba', 5)                                                             
'''------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
def yazdir(kelime, adet):                                       # modified by Chat GPT 
    print(''.join([kelime + " - "]*(adet-1) + [kelime]))
yazdir('merhaba', 5)
'''------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
def kezYolla(kelime, adet):
    i = 1
    while i < adet:
        print (f'{i}.{kelime}',end=' - ')
        i+=1
        if i == adet:
            print (f'{i}.{kelime}')
kullanicigirisi = input('Tekrar etmesini istediginiz kelimeyi ve miktarini bir bosluk birakarak giriniz: ')
ayrik = kullanicigirisi.split(' ')
kezYolla(ayrik[0],int(ayrik[1]))


'''================================================================================================================================================================================================'''


# 2- Kendine gonderilen sinirsiz sayidaki parametreyi bir listeye ceviren fonksiyon yazin
def listeyeCevir(*params):
    liste = []
    for param in params:
        liste.append(param)
    return liste
result = listeyeCevir(5,7,9,11,'noname')
print(result)


'''================================================================================================================================================================================================'''


# 3- Gonderilen 2 sayi arasindaki tum asal sayilari bulun.
def asalBulan(sayi1, sayi2):
    for sayi in range (sayi1, sayi2+1):
        if sayi > 1:
            for i in range (2, sayi):
                if (sayi % i == 0):
                    break
            else:
                print(sayi)

gir1 = int(input("ilk sayiyi girin: "))
gir2 = int(input("ikinci sayiyi girin: "))
asalBulan(gir1, gir2)


'''================================================================================================================================================================================================'''


# 4- Kendisine gonderilen bir sayinin tam bolenlerini bir liste seklinde dondurun.
def tamBolenleriBul(bolunen):
    bolenlerlist = []
    for bolen in range (1, bolunen+1):
        if bolunen % bolen == 0:
            bolenlerlist.append(bolen)
    return bolenlerlist
gir3 = int(input('Kontrol edilmesini istediginiz sayiyi girin: '))
print(tamBolenleriBul(gir3))




