maasAli = 5000
maasAhmet = 4000
vergi = 0.27

print (maasAli - (maasAli * vergi))
print (maasAhmet - (maasAhmet * vergi))

#Değişken Tanımlama Kuralları

# rakam ile başlayamaz

number1 = 10
print(number1)

number1 = 20
print(number1)

number1 += 30
print(number1)

# Buyuk kucuk harf duyarliligi

age = 20
AGE = 30

print(age)
print(AGE)

# Turkce karakter kullanmayalim

yas = 20
_age = 20

x = 1                    # int
y = 2                    # float
name = "Taha"            # string
isStudent = True         # bool

# x, y, name, isStudent = (1, 2.3, "Ikram", True)

a = '10'
b = '20'
print(a+b) # 30 => 1020

firstName = "Taha"
lastName = " Ozdogan"

print(firstName + lastName) # Taha Ozdogan