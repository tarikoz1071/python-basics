website = "http://www.tahaozdogan.com"
course = "Python Kursu, KODLUYORUZ.COM Bastan Sona Python Programlama Rehberiniz. (40 saat)"

# 1- ' Hello World ' karakter dizisinin bas ve sondaki bosluk karakterlerini silin.
result = ' Hello World '.strip()
result = ' Hello World '.lstrip()
result = ' Hello World '.rstrip()
result = website.lstrip(':/pth')

# 2 - 'www.tahaozdogan.com' icindeki tahaozdogan bilgisi haricindeki her karakteri silin.
result = 'www.tahaozdogan.com'.split('.')       # print(result[1])
result = 'www.tahaozdogan.com'.strip('w.moc')

# 3- 'course' karakter dizisinin tum karakterlerini kucuk harf yapin.
result = course.lower()
result = course.upper()
result = course.title()

# 4- 'website' icinde kac tane a karakteri vardir? (count('a'))
result = website.count('a')
result = website.count('www')
result = website.count('www',0,10)

# 5- 'website' 'www' ile baslayip com ile bitiyor mu?
result = website.startswith('http')
isFound = website.startswith('www')
isFound2 = website.endswith('com')
result = f'www ile basliyor mu?: {isFound} \ncom ile bitiyor mu?: {isFound2}' 

# 6- 'website' icinde '.com' ifadesi var mi?
result = website.find('.com')
result = website.find('.com',0,10)
result = course.find('Python')
result = course.rfind('Python')

result = website.index('com')
result = website.rindex('com')
# result = website.rindex('comm')
# 7- 'course' icindeki karakterlerin hepsi alfabetik mi? (isalpha, isdigit)
result = course.isalpha()
result = 'Hello'.isalpha()
result = course.isdigit()

# 8- 'Contents' ifadesini satirda 50 karakter icine yerlestirip sag ve soluna * ekleyiniz.
result = 'Contents'.center(50,'*')
result = 'Contents'.ljust(50,'*')
result = 'Contents'.rjust(50,'*')


# 9- 'course' karakter dizisindeki tum bosluk karakterlerini '-' ile degistirin.
result = course.replace(' ','-')
result = course.replace(' ','-',5)
result = course.replace(' ','')

# 10- 'Hello World' karakter dizisinin 'World' ifadesini 'There' olarak degistirin.
result = 'Hello World'.replace('World','There')

# 11- 'course' karakter dizisini bosluk karakterlerinden ayirin.
result = course.split(' ')
result = result[2]

print(result)