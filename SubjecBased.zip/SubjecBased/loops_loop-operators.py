import time
ask = input('Calistirmak istediginiz adim(lar)i giriniz: ')
calledsteps = ask.split()
time.sleep(0.5)
alt = 0


def step1():
    #range
    iplist =  []
    for octet in range (1,33,1):
        iplist.append({'username':'admin','password':'pldemo00','ip':f'172.21.45.{octet}'})
        print (iplist)
    print ('\n\n\n======\n\n\n')
    print (iplist)


def step2():
    #range
    for item in range(10,100,7):
        print(item)
    print(list(range(10,100,7)))


def step3():
    #enumerate
    index = 0
    greeting = 'Hello'
    for letter in greeting:
        print(f'index:{index} letter:{letter}')
        index += 1
    for index,letter in enumerate(greeting):print(f'index:{index} letter:{letter}')
    for item in enumerate(greeting):print(item)


def step4():
    # zip
    list1 = [1,2,3,4,5]
    list2 = ['a','b','c','d','e']
    list3 = [101,201,301,401,501]
    print(list(zip(list1,list2,list3)))
    for item in zip(list1,list2,list3):
        print(item)
    for x,y,z, in zip(list1,list2,list3):
        print(x,y)

def secenekler():
    if ('1' in calledsteps) or ('all' in calledsteps):
        step1()
    if ('2' in calledsteps) or ('all' in calledsteps):
        step2()
    if ('3' in calledsteps) or ('all' in calledsteps):
        step3()
    if ('4' in calledsteps) or ('all' in calledsteps):
        step4()

secenekler()