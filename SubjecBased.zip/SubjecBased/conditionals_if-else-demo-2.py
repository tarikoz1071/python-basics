# 1- Girilen bir sayinin 0-100 arasinda olup olmadigini kontrol ediniz.
sayi = int(input("bir sayi giriniz: "))
if (sayi > 0) and (sayi < 100):print (f'sayi 0-100 arasinda')
elif (sayi < 0) or (sayi > 100):print (f'sayi 0-100 arasinda degildir.')
elif (sayi == 0):print (f"girilen sayi 0'dir.")
elif (sayi == 100):print (f"girilen sayi 100'dur.")
else:(f"girilen sayi 100'dur.")


# 2- Girilen bir sayinin pozitif cift sayi olup olmadigini kontrol ediniz.
if (sayi>0):
    if (sayi%2==0):print(f'girilen sayi cift ve pozitiftir.')
    elif (sayi%2!=0):print(f'girilen sayi pozitiftir ancak cift degildir.')
elif (sayi<0):
    if (sayi%2==0):print(f'girilen sayi cifttir ancak negatiftir.')
    elif (sayi%2!=0):print(f'girilen sayi negatiftir ve ciftte degildir.')


# 3- Email ve parola bilgileri ile giris kontrolu yapiniz.
email = 'email@tahaozdogan'
password = 'abc123'
girilenEmail = input('email: ')
girilenPassword = input('password: ')
if girilenEmail == email:
    if girilenPassword == password: print(f"uygulamaya giris basarilidir.")
    elif girilenPassword != 'abc123': print(f"yanlis sifre.")
elif girilenEmail != 'email@tahaozdogan': print(f"yanlis kullanici adi.")


# 4- Girilen 3 sayiyi buyukluk olarak karsilastiriniz.
# ============ MY CODE ============
a,b,c = float(input("a= ")), float(input("b= ")), float(input("c= "))
if (a > b):
    if (a > c):print(f"a en buyuk sayidir")
    elif (a == c):print (f"a ve c esit ve en buyuk sayilardir")
    elif (a < c):print (f"c en buyuk sayidir")
elif (b > a):
    if (b > c):print(f"b en buyuk sayidir")
    elif (b == c):print (f"b ve c esit ve en buyuk sayilardir")        
    elif (b < c):print(f"c en buyuk sayidir")
elif (c > a):
    if (c > b):print(f"c en buyuk sayidir")
    elif (c == b):print (f"c ve b esit ve en buyuk sayilardir")        
    elif (c < b):print(f"b en buyuk sayidir")
elif (a == b):
    if (a > c):print(f"a ve b esit ve en buyuk sayilardir")
    elif (a == c):print (f"tum sayilar esittir")
    elif (a < c):print(f"c en buyuk sayidir")
elif (b == c):
    if (b > a):print(f"b ve c esit ve en buyuk sayilardir")
    elif (b == a):print (f"tum sayilar esittir")
    elif (b < a):print(f"a en buyuk sayidir")
# ============ CHAT GPT (enhanced my code) ============
# a,b,c = float(input("a= ")), float(input("b= ")), float(input("c= "))
if (a > b) and (a > c): print(f'a en buyuk sayidir.')
elif (b > a) and (b > c): print(f'b en buyuk sayidir.')
elif (c > a) and (c > b): print(f'c en buyuk sayidir.')
elif (a == b) and (b > c): print(f'a ve b esittir ve en buyuk sayilardir.')
elif (a == c) and (c > b): print(f'a ve c esittir ve en buyuk sayilardir.')
elif (b == c) and (c > a): print(f'b ve c esittir ve en buyuk sayilardir.')
elif (a == b) and (b == c): print(f'tum sayilar birbirine esittir.')


# 5- Kullanicidan 2 vize (%60) ve final (%40) notunu alip ortalama hesaplayiniz.
#    Eger ortalama 50 ve ustundeyse gecti degilse kaldi yazdirin.
#    a-) Ortalama 50 olsa bile final notu en az 50 olmalidir.
#    b-) Finalden 70 alindiginda ortalamanin onemi olmasin.
vize1 = float(input("vize1: "))
if (vize1 >= 0) and (vize1 <= 100):
    vize2 = float(input("vize2: "))
    if (vize2 >= 0) and (vize2 <= 100):
        final = float(input("final: "))
        ortalama = ((vize1+vize2)/2)*0.6 + final*0.4
        if (final >= 70) and (final <= 100):
            print(f"Final notu {final} (>=70) oldugundan ortalamanin onemi yoktur ve sonuc: GECTI! ")
        elif (final >= 0) and (final < 70):
            if (ortalama >= 50):print(f"Ortalama {ortalama} (>=50) oldugundan sonuc: GECTI! ")
            elif (ortalama < 50):print(f"Ortalama {ortalama} (<50) oldugundan sonuc: KALDI! ")
        else:print(f"Hatali not girisi (sinav notu [0-100] araliginda olmalidir): {final}")
    else: print(f"Hatali not girisi (sinav notu [0-100] araliginda olmalidir): {vize2}")
else: print(f"Hatali not girisi (sinav notu [0-100] araliginda olmalidir): {vize1}")


# 6- Kisinin ad, kilo ve boy bilgilerini alip kilo indekslerini hesaplayiniz.
#    Formul: (Kilo / boy uzunlugunun karesi)
#    Asagidaki tabloya gore kisi hanhi gruba girmektedir.
#    0-18.4 => Zayif
#    18.5-24.9 => Normal
#    25.0-29.9 => Fazla Kilolu
#    30.0-34.9 => Sisman (Obez)
print ('\n----------INDEKS HESAPLAYICISI----------')
name = input('adiniz: ')
kg = float(input('kilonuz: '))
hg = float(input('boyunuz: '))
index = (kg) / (hg ** 2)
print ('\n----------INDEKS TABLOSU----------')
print ('zayif = 0 - 18.4')
print ('normal = 18.4 - 24.9)')
print ('kilolu = 24.9 - 29.9)')
print ('obez = 29.9 - 34.9)\n')
if (index >= 0) and (index <= 18.4):print (f'Merhaba {name}, kilo indeksin: {index} ve kilo degerlendirmen: ZAYIF')    
elif (index > 18.4) and (index <= 24.9):print (f'Merhaba {name}, kilo indeksin: {index} ve kilo degerlendirmen: NORMAL')
elif (index > 24.9) and (index <= 29.9):print (f'Merhaba {name}, kilo indeksin: {index} ve kilo degerlendirmen: KILOLU')
elif (index > 29.9) and (index <= 34.9):print (f'Merhaba {name}, kilo indeksin: {index} ve kilo degerlendirmen: OBEZ')
else: print (f'Merhaba {name}, kilo indeksin {index} olup yukaridaki tabloda bulunan degerlerden herhangi birine uymamaktadir.')

# print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen zayif: {zayif}')
# print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen normal: {normal}')
# print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen kilolu: {kilolu}')
# print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen obez: {obez}')

