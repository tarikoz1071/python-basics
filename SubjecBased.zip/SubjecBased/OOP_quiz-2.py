

class Question:                       # Soru objelerinin tanimlanacagi bir siniftir 
    def __init__(self, text, choices, answer):
        self.text = text
        self.choices = choices
        self.answer = answer.lower()

    def checkAnswer(self, answer):
        return self.answer == answer




class Quiz:                            # Sorularin sorulacagi, ilerletilecegi, sonlandirilacagi ve puanlamanin tutulacagi alan.
    def __init__(self, questions):
        self.questions = questions
        self.score = 0
        self.questionIndex = 0

    def getQuestion(self):
        return self.questions[self.questionIndex]

    def displayQuestion(self):
        question = self.getQuestion()
        print(f'Question {self.questionIndex + 1}: {question.text}' )
        for c in question.choices:print('-' + c)
        answer = (input('Your Answer: ')).lower()
        self.guess(answer)
        self.loadQuestion()

    def guess(self, answer):
        question = self.getQuestion()
        if question.checkAnswer(answer):
            self.score = self.score + 1
        self.questionIndex = self.questionIndex + 1
    
    def loadQuestion(self):
        if len(self.questions) == self.questionIndex:
            self.showScore()
        else:
            self.displayProgress()
            self.displayQuestion()



    def showScore(self):
        print ('\n',' Quiz has ended. ' f'Your Score: {self.score} '.center(70,'*'))
    
    def displayProgress(self):
        totalQuestion = len(self.questions)
        questionNumber = self.questionIndex + 1
        print(f'  {questionNumber} out of {totalQuestion}  '.center(70,'='))        


q1 = Question('En iyi programlama dili hangisidir?', ['C#','Python','Java','JavaScript'], 'Python')
q2 = Question('En yaygin programlama dili hangisidir?',['Python','C#','Java','JavaScript'],'Python')
q3 = Question('En cok kazandiran programlama dili hangisidir?',['Java','Python','C#','JavaScript'],'Python')
questions = [q1,q2,q3]                              # Class icinde "questions" adlı value alanina denk gelir.

quiz = Quiz(questions)    
quiz.loadQuestion()

