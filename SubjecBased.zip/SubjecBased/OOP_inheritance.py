# Inheritance (Kalıtım): Miras alma

# Person => name, lastname, age, eat(), run(), drink()
# Student(Person), Teacher(Person)

# Animal => Dog(), Cat()

class Person():
    def __init__(self, fname, lname):
        self.firstName = fname
        self.lastName = lname
        print('Person Created')
    def who_am_i(self):
        print('I am a person')
    def eat(self):
        print('I am eating')


class Student(Person):
    def __init__(self, fname, lname, snumber):
        Person.__init__(self, fname, lname)
        self.studentNumber = snumber
        print('Student Created')
    # override
    def who_am_i(self):
        print('I am a student')
    def sayHello(self):
        print('Hello I am a student')



class Teacher(Person):
    def __init__(self, fname, lname, branch):
        super().__init__(fname, lname)
        self.dersbranch = branch
    def who_am_i(self):
        print(f'I am a {self.dersbranch} teacher')


p1 = Person(fname='Unal', lname='Yildiz')
s1 = Student('Abdurrahman','Onul',1507)
t1 = Teacher('Ayhan', 'Penez', 'Beden')


print(p1.firstName + ' ' + p1.lastName)
print(s1.firstName + ' ' + s1.lastName + ' ' + str(s1.studentNumber))
print(t1.firstName + ' ' + t1.lastName + ' ' + t1.dersbranch)

p1.who_am_i()
s1.who_am_i()
p1.eat()
s1.eat()
s1.sayHello()
t1.who_am_i()