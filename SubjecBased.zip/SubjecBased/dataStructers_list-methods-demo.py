names = ['Vakkas', 'Edip', 'Erkan', 'Abdurrahim', 'Murat']
years = [1975, 1955, 1973, 1998, 1970]

# 1- "Emrah" ismini listenin sonuna ekleyiniz.
names.append('Emrah')               # names.insert(len(names), 'Emrah')
# 2- "Yucel" degerini listenin basina ekleyiniz.
names.insert(0, 'Yucel')
# 3- "Abdurrahim" ismini listeden siliniz.
names.remove('Abdurrahim')          # names.pop(3)
# 4- "Edip" isminin  indeksi nedir?
result = names.index('Edip')
# 5- "Vakkas" listenin bir elemani midir?
result = 'Vakkas' in names          # result = names.index('Vakkas')
# 6- Liste elemanlarini ters cevirin
names.reverse()
# 7- Liste elemanlarini alfabetik olarak siralayiniz.
names.sort()
# 8- years listesini rakamsal buyukluge gore siralayiniz.
years.sort()
# 9- str = "Togg,Devrim" karakter dizsini listeye ceviriniz.
str = "Togg,Devrim"
result = str.split(',')
# 10- years dizisinin en buyuk ve en kucuk elemani nedir?
val = min(years)
val = max(years)
# 11- years dizisinde kac tane 1998 degeri vardir?
val = years.count(1998)
# 12- years dizisinin tum elemanlarini siliniz.
val = years.clear()
# 13- Kullanicidan alacaginiz 3 tane marka bilgisini bir listede saklayiniz.
aracmarkalari = []

markagir = input("marka ekleyiniz: ")
aracmarkalari.append(markagir)

markagir = input("marka ekleyiniz: ")
aracmarkalari.append(markagir)

markagir = input("marka ekleyiniz: ")
aracmarkalari.append(markagir)

print(aracmarkalari)

# userliste = input('Birer bosluk birakarak 3 farkli marka giriniz: ').split()



print(result)
print(names)
print(years)
print(val)
# print(userliste)










