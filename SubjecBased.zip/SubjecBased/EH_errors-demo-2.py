
liste = ["1","2","7c","123b","cxz","11","53"]


# 1- Liste elemanlari icindeki sayisal degerleri bulunuz.
i=0
cevrilenlerlist = []
while i <= (len(liste)-1): 
    # print(i)
    try:
        print(int(liste[i]))
        cevrilenlerlist.append(int(liste[i]))
    except:
        print(f'"{liste[i-1]}" elemani cevrilemedi')
    finally:
        i += 1
        print(cevrilenlerlist)
        
    

# 2- Kullanici 'q' degerini girmedikce aldiginiz her inpputun sayi
# oldugundan emin olunuz aksi halde hata mesaji yazin.
numList=[]
while True:
    try:
        number = input("Enter a number (Type 'q' to finish): ")
        if number != 'q':
            numList.append(int(number))
        elif number == 'q':
            break
    except:
        print(f"{number} is not accepted Please enter a number.")
        continue
print(numList)




# 3- Girilen parola icinde turkce karakter hatasi tanimlayiniz.
import re  
for j in range(13):
    try:
        password = input('Enter your password: ')
        if not any (a in password for a in 'çğöış'):
            if password:
                if re.search(r'\s', password) is None:
                    print('Password accepted.')
                    break
        elif 'ç' in password or 'ğ' in password or 'ö' in password or 'ı' in password or 'ş' in password:
            print('Password not accepted. Try Again.')
            continue
    except:
        pass



# 4- Faktoriyel fonksiyonu olusturup fonksiyona gelen deger icin
# hata mesajlari verin.
from math import factorial

def fini(f):
    
    if re.search(r'[a-zA-Z]', f) is not None or re.search(r'[!@#$%^&*()_+=-|"\']', f) is not None:
        print("Error: input contains non-numeric characters.")
    elif re.search(r'\s', f) is not None:
        print("Error: input contains space.")
    elif not f:
        print("Error: Nothing entered.")
    else:
        return factorial(int(f))
    

while True:
    enterfact = input("Enter a number to calculate it's factorial: ")
    result = fini(enterfact)
    if result is not None:
        print(result)
        break
    else:
        continue

    # try:
    #     enterfacto = input("Enter a number to calculate it's factorial: ")
    #     result = facto(enterfacto)
    #     if result is not None:
    #         print(result)
    #     elif result is None:

    #         pass
    # except:
    #     pass







