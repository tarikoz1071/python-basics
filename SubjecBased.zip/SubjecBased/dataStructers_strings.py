name = 'Sadik'
surname = 'Turan'
age = 36

deneme = 'My name is'

greeting = deneme + ' ' + name+' '+surname + ' and \nI am' + ' ' + str(age) + ' years old.'
length=len(greeting)
#print(greeting)
# print(greeting[0])
# print(greeting[3])
# print(greeting[length-1])
# print(greeting[-1])

# print(greeting[3:7])    # 3 ve 7 haric
# print(greeting[3:])
# print(greeting[:16])
print(greeting[2:40:3])