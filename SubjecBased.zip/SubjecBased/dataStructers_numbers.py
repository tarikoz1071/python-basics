# tip ogrenme
print(type(2))
print(type(2.0))

# toplama ve cikarma
print(2+2)
print(2+1.5)
print(3-1)
print(3-1.5)

# carpma ve bolme ("*" isareti carpma "/" isareti bolme icin kullanilir)
print(10*5)
print((2+10)*(10+8))
print(10/5)
print((15+13)/(5+2))

# us alma
print(2**3)
print(3**0.5)   # 3 uzeri 1/2

# mod alma
print(10 % 2)
print(11 % 2)

# ondaliksiz bolme (asagiya yuvarlar)
print(15//4)
print(-15//4)   # tam sonuc -3.3333'tür ancak asagisi -4 oldugu icin -4'e yuvarlar. 
