# error handling => hata yonetimi
# try:
#     x = int(input('x: '))
#     y = int(input('y: '))
#     print(x/y)
# except ZeroDivisionError:
#     print('y icin 0 girilemez')
# except ValueError:
#     print('x ve y icin sayisal deger girin.')


# except (ZeroDivisionError, ValueError) as e:
#     print('yanlis bilgi girdiniz')
#     print(e)


# except:
#     print('yanlis bilgi girdiniz')


while True:
    try:
        x = int(input('x: '))
        y = int(input('y: '))
        print(x/y)
    except Exception as ex:
        print('yanlis bilgi girdiniz. Detay: ',ex)
    else:
        break
    finally:
        print('try except sonlandi.')