'''
Soru: Girilen bir sayinin asal olup olmadigini bulun.
** Asal Sayi 1 ve kendisi haric tam boleni olmayan
   sayilara denir.
'''
sayi = int(input('Kontrol etmek istediginiz sayiyi giriniz: '))
asalmi = True
if sayi<2: asalmi = False

for i in range(2,sayi):
    if (sayi % i == 0):
        asalmi = False
        break
if asalmi:
    print('sayi asaldir.')
else:
    print('sayi asal degildir.')

