x = int(input('x: '))
y = int(input('y: '))

if x > y:
    print('x y den buyuk')
elif x == y:
    print('x y esit')
else:
    print('y x den buyuk')

num = int(input('sayi: '))

if num > 0:
    print('sayi pozitif')
elif num < 0:
    print('sayi negatif')
else:
    print('sayi sifir')