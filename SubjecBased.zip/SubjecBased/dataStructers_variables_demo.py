"""

1- Bir mustarinin asagidaki bilgileri icin degisken olusturunuz.

    Musteri adi
    Musteri soyadi
    Musteri ad + soyad
    Musteri cinsiyet
    Musteri tc kimlik
    Musteri dogum yili
    Musteri adres bilgisi
    Musteri yasi
"""

musteriadi, musterisoyadi, mustericinsiyet, musteritckimlik, musteridogumyili, musteriadresbilgisi, = ("taha", "ozdogan", "True", '11111111111', 1517, "topkapi sarayi oda no:23")
#Cinsiyet True = Erkek 
musteriadsoyad = musteriadi + ' ' + musterisoyadi
musteriyasi = 2022 - musteridogumyili
print (musteriadsoyad, musteriyasi)

"""
    2- Asagidaki siparislerin toplam bilgisini hesaplayiniz.

    Siparis 1 => 110 TL
    Siparis 2 => 1100.5 TL
    Siparis 3 => 356.95 TL
"""

s1 = 110
s2 = 1100.5
s3 = 356.95

toplamHesap = s1+s2+s3
print("Toplam: ", toplamHesap)