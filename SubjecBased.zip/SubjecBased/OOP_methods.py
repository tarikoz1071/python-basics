class Person:
    # class attributes
    adresi = 'no information'
    # constructor (yapici metod)
    def __init__(self, name, year):
        # object attributes
        self.adi = name
        self.yili = year
    # instance methods
    def intro(self):
        print('Hello There I am ' + self.adi)
    def calculateAge(self):
        return 2023 - self.yili

# object (instance)
p1 = Person(name = 'Hassan', year = 1977 )
p2 = Person('Ali', 1999)
p1.intro()
p2.intro()
print(f'adım:{p1.adi} ve yaşım: {p1.calculateAge()}')
print(f'adım:{p2.adi} ve yaşım: {p2.calculateAge()}')


class Circle:
    # Class object attribute
    pisayisi = 3.14
    def __init__(self, radius=1):               # eger yaricap belirtilmez ise 1 yapilacaktir.
        self.yaricap = radius
    # Methods
    def cevre_hesapla(self):
        return 2*self.pisayisi * self.yaricap
    def alan_hesapla(self):
        return self.pisayisi * (self.yaricap**2)

c1 = Circle() 
c2 = Circle(5)

print(f'c1 : alan = {c1.alan_hesapla()}, cevre= {c1.cevre_hesapla()}')
print(f'c2 : alan = {c2.alan_hesapla()}, cevre= {c2.cevre_hesapla()}')