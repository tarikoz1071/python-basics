# username, password => database
# 'tahaozdogan', '123123'
a, b, c, d = 5, 5, 10, 4
password = '1234'
username = 'tahaozdogan'
result = (a == b)  # True
result2 = (a == c) # False
result3 = ('tahaozdn' == username) 
result4 = ('tahaozdogan' == username) 
result5 = (a != b) 
result6 = (a != c) 
result7 = (a > c) 
result8 = (a < c) 
result9 = (a >= b) 
result10 = (c <= b)
result11 = (True == 1)
result12 = (False == 0)
result13 = False + True + 40


print (result)
print (result2)
print (result3)
print (result4)
print (result5)
print (result6)
print (result7)
print (result8)
print (result9)
print (result10)
print (result11)
print (result12)
print (result13)
