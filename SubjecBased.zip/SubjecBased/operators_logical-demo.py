# 1- Girilen bir sayinin 0-100 arasinda olup olmadigini kontrol ediniz.
sayi = int(input("bir sayi giriniz: "))
# result1 = 0 < sayi <= 100
result1 = (sayi > 0) and (sayi < 100)
print (f'sayi 0-100 arasinda mi: {result1}')


# 2- Girilen bir sayinin pozitif cift sayi olup olmadigini kontrol ediniz.
result2 = (sayi>0) and (sayi%2==0)
print (f'girilen sayi pozitif cift sayi mi: {result2}')


# 3- Email ve parola bilgileri ile giris kontrolu yapiniz.
email = 'email@tahaozdogan'
password = 'abc123'
girilenEmail = input('email: ')
girilenPassword = input('password: ')
result3 = (girilenEmail == email) and (girilenPassword == password)
print (f"uygulamaya giris basarili mi: {result3}")


# 4- Girilen 3 sayiyi buyukluk olarak karsilastiriniz.
a,b,c = float(input("a= ")), float(input("b= ")), float(input("c= "))
result4 = (a > b) and (a > c)
print(f"a en buyuk sayidir: {result4}")
result4 = (b > a) and (b > c)
print(f"b en buyuk sayidir: {result4}")
result4 = (c > a) and (c > b)
print(f"c en buyuk sayidir: {result4}")


# 5- Kullanicidan 2 vize (%60) ve final (%40) notunu alip ortalama hesaplayiniz.
#    Eger ortalama 50 ve ustundeyse gecti degilse kaldi yazdirin.
#    a-) Ortalama 50 olsa bile final notu en az 50 olmalidir.
#    b-) Finalden 70 alindiginda ortalamanin onemi olmasin.
vize1,vize2,final = float(input("vize1: ")), float(input("vize2: ")), float(input("final: "))
ortalama = ((vize1+vize2)/2)*0.6 + final*0.4
result5 = (ortalama >= 50) and (final >= 50)
print(f"Gecer not 50 olduguna gore ve final notu en az 50 ise {ortalama} ortalama ve {final} final notu ile gecti mi?: {result5}")
result6 = (ortalama >= 50) or (final >= 70)
print(f"Final notu en az 70 ise {ortalama} ortalama yok sayilarak {final} final notu ile gecti mi?: {result6}")


# 6- Kisinin ad, kilo ve boy bilgilerini alip kilo indekslerini hesaplayiniz.
#    Formul: (Kilo / boy uzunlugunun karesi)
#    Asagidaki tabloya gore kisi hanhi gruba girmektedir.
#    0-18.4 => Zayif
#    18.5-24.9 => Normal
#    25.0-29.9 => Fazla Kilolu
#    30.0-34.9 => Sisman (Obez)
name = input('adiniz: ')
kg = float(input('kilonuz: '))
hg = float(input('boyunuz: '))
index = (kg) / (hg ** 2)
zayif = (index >= 0) and (index <= 18.4)
normal = (index > 18.4) and (index <= 24.9)
kilolu = (index > 24.9) and (index <= 29.9)
obez = (index > 29.9) and (index <= 34.9)
print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen zayif: {zayif}')
print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen normal: {normal}')
print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen kilolu: {kilolu}')
print (f'{name} kilo indeksin: {index} ve kilo degerlendirmen obez: {obez}')
# indekslist = [[input("1.kisi ismi: "),float(input("1.kisi kilosu: ")),float(input("1.kisi boyu: "))], [input("2.kisi ismi: "),float(input("2.kisi kilosu: ")),float(input("2.kisi boyu: "))], [input("3.kisi ismi: "),float(input("3.kisi kilosu: ")),float(input("3.kisi boyu: "))]]
# aindex = float((indekslist[0][1])/(indekslist[0][2]*indekslist[0][2]))
# bindex = float((indekslist[1][1])/(indekslist[1][2]*indekslist[1][2]))
# cindex = float((indekslist[2][1])/(indekslist[2][2]*indekslist[2][2]))
# azayif = 0 <= aindex <= 18.4
# anormal = 18.5 <= aindex <= 24.9
# afkilo = 25.0 <= aindex <= 29.9
# aobez = 30.0 <= aindex <= 34.9
# bzayif = 0 < bindex < 18.4
# bnormal = 18.5 < bindex < 24.9
# bfkilo = 25.0 < bindex < 29.9
# bobez = 30.0 < bindex < 34.9
# czayif = 0 < cindex < 18.4
# cnormal = 18.5 < cindex < 24.9
# cfkilo = 25.0 < cindex < 29.9
# cobez = 30.0 < cindex < 34.9
# print (f"{indekslist[0][0]} isimli kisinin indeksi: {aindex} zayiflik->{azayif}, makulluk->{anormal}, kiloluluk->{afkilo}, obezite->{aobez}")
# print (f"{indekslist[1][0]} isimli kisinin indeksi: {bindex} zayiflik->{bzayif}, makulluk->{bnormal}, kiloluluk->{bfkilo}, obezite->{bobez}")
# print (f"{indekslist[2][0]} isimli kisinin indeksi: {cindex} zayiflik->{czayif}, makulluk->{cnormal}, kiloluluk->{cfkilo}, obezite->{cobez}")







