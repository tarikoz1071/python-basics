numbers = [1,2,3,4,5]
# numbers listesindeki elemanlari al a variable'ina ata.
for a in numbers:
    print(a)

names = ['ali', 'veli', 'mehmet', 'zeynep', 'ayse']

for name in names:
    print(f'my name is {name}')

name = 'Taha'

for n in name:
    print(n)

tuple = ((1,2), (3,4), (5,7), (11,13))

for x,y in tuple:
    print(y)

s = {'k1':1, 'k2':2, 'k3':3}

for key, value in s.items():
    print(key, value)