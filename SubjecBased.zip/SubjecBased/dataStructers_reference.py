# value types => string, number(int,float)
x = 5
y = 25
print(x, y)
x = y
print(x, y)
y = 10
print(x, y)


# reference types => list
a = ["apple", "pear"]
b = ["apple", "pear"]
print(a, b)
a=b
b[1] = "lemon"
print(a, b)
