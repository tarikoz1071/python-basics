'''
Aslinda Method ve Fonksiyon ayni amacla kullanilir ancak kullanilis yerleri farklidir.
1- Methodlari barindiran bir kod butunu 'class' olarak adlandirilir. (<class 'list'>)
2- Liste bir class tir ve icerisinde tanimlanmis metodlar mevcuttur.(e.g. pop, append)
3- methodlarin anlatimlari icin https://docs.python.org/3/

4- Fonksiyon ise method gibi belli amaclara yonelik olarak olusturulmus olan bir yapi.
Ancak fonksiyonlari class icerisine tanimlamiyoruz. Dolayisiyla tanimlamis oldugumuz
fonksiyonlara methodlarda oldugu gibi tanimlanan class ve classtanda turetilen nesne 
uzerinden ulasmiyoruzda direk fonksiyonlara fonksiyon isimleriyle ulasiyoruz. (orn 
bana 2 tane sayi gonder, bu sayilari toplayip sana gonderecegim)
'''

# method 
list = [1,2,3]
list.append(4)
list.pop()

print(type(list))
print(list)

myString = 'Hello'
print(type(myString))
print(myString)
print(myString.upper())


# fonksiyon



