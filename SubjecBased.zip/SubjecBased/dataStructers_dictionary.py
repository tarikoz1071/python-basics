# key - value

# 41 => kocaeli     34 => Istanbul

# sehirler = ['kocaeli', 'istanbul']
# plakalar = [41, 34]

# print(plakalar[sehirler.index('istanbul')])

# print(plakalar['kocaeli']) => 41
# print(plakalar['istanbul']) => 34

# plakalar = {'kocaeli' : 41, 'istanbul' : 34}

# print(plakalar['kocaeli'])
# print(plakalar['istanbul'])

# plakalar['ankara'] = 6
# plakalar['istanbul'] = 'islambol'

# print(plakalar)

users = {
    'tahaozdogan' : {
        'age': 25,
        'roles' : ['user'],
        'email' : 'tahaozdogan@gmail.com',
        'address' : 'kurtkoy',
        'phone' : '1232312'
    },
    'yasinozdogan' : {
        'age': 11,
        'roles' : ['admin','user'],
        'email' : 'yasinikozdogan@gmail.com',
        'address' : 'gaziosmanpasa',
        'phone' : '1232312'
    }
}


print(users['yasinozdogan'])
print(users['yasinozdogan']['age'])
print(users['yasinozdogan']['email'])
print(users['yasinozdogan']['address'])
print(users['yasinozdogan']['roles'][0])