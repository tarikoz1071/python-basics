# Object Oriented Programming (OOP)

# class -- Bizim icin kutuphane icerisinde daha onceden olusturulmus
#          ve belli basli bazi ozellikler/metodlar aktarilmis bir yapidir.

# instance (object)


lst1 = [1,2,3]      # burada tanimlamis oldugumuz bir liste, list 
lst2 = [1,2,3,4]    # class'indan kopyalanmis/turetilmis olan bir instance'dir.
                    # ve biz bir liste tanimladigimizda aslinda daha onceden olusturulmus
                    # olan class'in bir kopyasini olusturmus oluruz.



result = type(lst1)
result = type(lst2)
print(result)


# class =>      Biz kendi class larimizi da olusturabiliriz.
#               Ornegin uygulamada bir kullanici kaydi tutacagiz.
#               
#
# class =>      Person(name, surname, birthday, calculateAge()) 
#               Bir kisi icin yapacak olsak boyle bir class olusturma
#               ihtiyacimiz yok ancak herkes icin yapacaksak mantikli. 


