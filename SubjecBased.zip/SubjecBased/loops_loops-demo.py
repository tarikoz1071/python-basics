'''
1-100 arasinda rastgele uretilecek bir sayiyi asagi yukari ifadeleri ile
buldurmaya calisin (e.g. hak = 5)
** "random" modulu icin "python random" seklinde arama yapin.
** 100 uzerinden puanlama yapin. Her soru 20 puan.
** Hak bilgisini kullanicidan alin ve her soru belirtilen can saysisi
   uzerinden hesaplansin.
'''
import random
sayi = random.randint(1,50)
can = int(input('Kac hak kullanmak istersiniz: '))
hak = 5
hak = can
sayac = 0

while hak > 0:
   hak -= 1
   tahmin = int(input('tahmininiz: '))
   sayac += 1
   if sayac > 0 and tahmin == sayi:
      print(f'Tebrikler {sayac}. defada bildiniz!')
      print (f'Puaniniz: {100-((sayac-1)*(100/can))}')
      break
   elif tahmin < sayi:print('yukari')
   elif tahmin > sayi:print('asagi')
   if hak == 0:
      print(f'Hakkiniz bitti. Sayi "{sayi}" idi. Kazanilan puan: 0')




