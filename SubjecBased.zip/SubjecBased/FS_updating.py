with open ("newfile.txt", "r+", encoding="utf-8") as file:
    print(file.read)

with open ("newfile.txt", "r+", encoding="utf-8") as file:
    file.write("deneme")


# ************* Sayfa sonunda guncelleme ************* 
with open ("newfile.txt", "a", encoding="utf-8") as file:
    file.write("\nikinci deneme")

with open ("newfile.txt", "r", encoding="utf-8") as file:
    print(file.read)



# ************* Sayfa basinda guncelleme ************* 
with open ("newfile.txt", "r+", encoding="utf-8") as file:
    content=file.read()
    content="guncelleme\n"+content
    file.seek(0)
    file.write(content)

with open ("newfile.txt", "r", encoding="utf-8") as file:
    print(file.read)


# ************* Sayfa ortasinda guncelleme ************* 
with open ("newfile.txt", "r+", encoding="utf-8") as file:
    list = file.readlines()
    list.insert(1, "Edip Bayrak\n")
    file.seek(0)
#   file.writelines(list)    --- Asagidaki for dongusu yerine kisaca boyle yapabiliriz.
    for i in list:
        file.write(i)