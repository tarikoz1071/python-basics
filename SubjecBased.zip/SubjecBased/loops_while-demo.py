import time
a = input('Calistirmak istediginiz adim(lar)i giriniz: ')
cagirilanadimlar = a.split()
print (cagirilanadimlar)
b = 0

# 1: sayilar listesini while ile ekrana yazdirin.
def adim1():
    global b
    def adim1a():
        print('Adim-1a Calistiriliyor...')
        time.sleep(1)
        sayilar = [1,3,5,7,12,19,21]
        i = 0
        while (i < len(sayilar)):
            print(sayilar[i],end=' ')
            i += 1
        print('\n')

    time.sleep(1)
    while b < 1:
        isa = input('Alternatif adim calistirilsin mi?(Evet, Hayir, Her ikisi): ')
        if isa.lower() == 'evet':
            b += 1
            adim1a()
        elif isa.lower() == 'hayir':
            b += 1
            adim1()
        elif isa.lower() == 'her ikisi' or isa.lower() == 'herikisi':
            b += 1
            adim1a()
        else: 
            b += 1
            print('hatali tuslama...')
            exit()
    print('Adim-1 Calistiriliyor...')
    sayilar = [1,3,5,7,12,19,21]
    print('sayilar listesindeki eleman sayisi: ',len(sayilar),'\'dir.',sep='')
    while sayilar:
        print (sayilar[0],end=' ')
        sayilar = sayilar[1:]
    print('\n')



# 2: Baslangic ve Bitis degerlerini kullanicidan alip aradaki tum
#    tek sayilari ekrana yazdirin.
def adim2():
    print('Adim-2 Calistiriliyor...')
    time.sleep(1)
    sayilar = []
    teksayilar= []
    baslangic = input ('baslanilacak sayi: ')
    bitis = input ('son sayi: ')
    i = int(baslangic)
    while i <= int(bitis):
        sayilar.append(i)
        if i % 2 == 1:
            teksayilar.append(i)
        else:pass
        i += 1
    print (f'{sayilar} bu liste tum sayilari gosterir.')
    print (f'{teksayilar} bu liste tek olan sayilari gosterir.')
    print('\n')



# 3: 1-100 arasindaki sayilari azalan sekilde yazdirin.
def adim3():
    print('Adim-3 Calistiriliyor...')
    time.sleep(1)
    sayilar = []
    i = 100
    while i >= 0:
        sayilar.append(i)
        i -= 1
    print(sayilar)
    print('\n')



# 4: Kullanicidan alacaginiz 5 sayiyi ekranda sirali bir sekilde yazdirin.
def adim4():
    print('Adim-4 Calistiriliyor...')
    time.sleep(1)
    sayilar = []
    i = 1
    f = 0
    while i <= 5:
        f = int(input(f'{i}. sayiyi giriniz:'))
        sayilar.append(f)
        i += 1
    sayilar.sort()
    print(sayilar)
    print('\n')



# 5: Kullanicidan alacaginiz sinirsiz urun bilgisini urunler listesi icinde saklayin
#    ** urun sayisini kullaniciya sorun.
#    ** dictionary listesi yapisi (name, price) seklinde olsun.
#    ** urun ekleme islemi bittiginde urunleri ekranda while ile listeleyin.
def adim5():
    print('Adim-5 Calistiriliyor...')
    time.sleep(1)
    urunsayisi = int(input('Kac urun olacak: '))
    urunlist = []
    i = 1  #counter variable
    while i <= urunsayisi:
        name = input(f'{i}. urunun ismi: ')
        price = input(f'{i}. urunun fiyati: ')
        urunlist.append({'name':name,'price': price})
        i += 1 
    print (urunlist)
    for j in urunlist: 
        print (f"urun adi:{j['name']},fiyati:{j['price']}",end='  ')
    print('\n')



def secenekler():
    if ('1' in cagirilanadimlar) or ('all' in cagirilanadimlar):
        adim1()
    if ('2' in cagirilanadimlar) or ('all' in cagirilanadimlar):
        adim2()
    if ('3' in cagirilanadimlar) or ('all' in cagirilanadimlar):
        adim3()
    if ('4' in cagirilanadimlar) or ('all' in cagirilanadimlar):
        adim4()
    if ('5' in cagirilanadimlar) or ('all' in cagirilanadimlar):
        adim5()

secenekler()


