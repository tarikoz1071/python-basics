'''===============================FUNCS AND VARIABLES======================================================================================================'''
def square(num): return num**2
numbers = [1,3,5,9,12,22,21,30,34,33]
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
result1 = list(map(square, numbers))
print(f'{result1}\n')                   # Ilk yontem, "map" built-in fonks. kullanip sonucunu listeye cevirerek: 
# print(''.join(str(result1)) + '\n')
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
for item in (map(square, numbers)):         # print('Ikinci yontem, "map" built-in fonks. kullanip sonucunu "for" loop ile itere ederek ekrana basmak: ',end='')
    print('{}'.format(item),end=" ")




'''==============================LAMBDA (PORTABLE FUNCT.) METHOD============================================================================================'''
result2 = list(map(lambda num: num ** 2, numbers))      #Yukaridaki fonksiyon olmasa bile calisir.
print('\n\n{}'.format(result2))                     # 3. ve nihai amacimiz olan yontem, tek kullanimlik fonksiyon yani "lambda" yontemi kullanarak
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
isimlendirilmisfonksiyon = lambda num: num ** 2
result3 = list(map(isimlendirilmisfonksiyon, numbers))
print(f'\n\n{result3}')                                 # 3. yontem, alternatif "lambda" yontemi (isimlendirilmis tek kull. fonks.) kullanarak
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
isimlendirilmisfonksiyon2 = lambda num: num ** 2
result4 = isimlendirilmisfonksiyon2(3)
print(f'\n\n{result4}\n')                               # 3. yontem, fonks. cagirip arguman bazinda calistirma




'''==============================SPECIFIC RETRUN (FILTER)======================================================================================================'''
def check_even(num): return num%2==0
result5 = list(filter(check_even, numbers))
print (result5)
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
result6 = list(filter(lambda num2: num2%2==0, numbers))
print (result6)
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
check_even2 = lambda num2: num2%2==0
result7 = list(filter(check_even2, numbers))
print (result7)
'''--------------------------------------------------------------------------------------------------------------------------------------------------------'''
check_even3 = lambda num3: num3%2==0
result8 = check_even3(numbers[5])
print (result8)
