

class Soru:                       # Soru objelerinin tanimlanacagi bir siniftir 
    def __init__(kendi, text, choices, answer):
        kendi.metin = text
        kendi.secenekler = choices
        kendi.cevap = answer.lower()

    def checkAnswer(kendi, answer):
        return kendi.cevap == answer




class AraSinav:                            # Sorularin sorulacagi, ilerletilecegi, sonlandirilacagi ve puanlamanin tutulacagi alan.
    def __init__(kendi, questions):
        kendi.sorular = questions
        kendi.puan = 0
        kendi.soruSirasi = 0

    def getQuestion(kendi):
        return kendi.sorular[kendi.soruSirasi]

    def displayQuestion(kendi):
        ekrandakisoru = kendi.getQuestion()
        print(f'Soru {kendi.soruSirasi + 1}: {ekrandakisoru.metin}' )
        for s in ekrandakisoru.secenekler:print('-' + s)
        yanit = (input('Cevap: ')).lower()
        kendi.guess(yanit)
        kendi.loadQuestion()

    def guess(kendi, answer):
        ekrandakisoru = kendi.getQuestion()
        if ekrandakisoru.checkAnswer(answer):
            kendi.puan = kendi.puan + 1
        kendi.soruSirasi = kendi.soruSirasi + 1
    
    def loadQuestion(kendi):
        if len(kendi.sorular) == kendi.soruSirasi:
            kendi.showScore()
        else:
            kendi.displayProgress()
            kendi.displayQuestion()

    def showScore(kendi):
        print ('score: ', kendi.puan)
    
    def displayProgress(kendi):
        toplamSoru = len(kendi.sorular)
        soruNumarasi = kendi.soruSirasi + 1
        if soruNumarasi == toplamSoru:
            print('Ara Sinav bitti.')
        else:
            print('')
            print(f'  {toplamSoru} sorundan {soruNumarasi}. sorudasiniz.  '.center(70,'='))        


s1 = Soru('En iyi programlama dili hangisidir?', ['C#','Python','Java','JavaScript'], 'Python')
s2 = Soru('En yaygin programlama dili hangisidir?',['Python','C#','Java','JavaScript'],'Python')
s3 = Soru('En cok kazandiran programlama dili hangisidir?',['Java','Python','C#','JavaScript'],'Python')
soruListesi = [s1,s2,s3]                              # Class icinde "questions" adlı value alanina denk gelir.

kitapcik = AraSinav(soruListesi)    
kitapcik.loadQuestion()

