message = 'Hello There. My name is Taha Ozdogan'.split()
# print(message[0])

# my_list = [1,2,3]
# my_list = ['bir', 2,True, 5.6]
# print(my_list)

list1 = ['one','two','three']
list2 = ['four','five','six']
numbers = list1 + list2
print(numbers)
print(len(numbers))
print(message[0])
print(numbers[2])

# userA = ['Taha', 25]
# userB = ['Yasin', 10]
# users = userA + userB
# print(userA)
# print(userB)
# print(users)

userA = ['Taha', 25]
userB = ['Yasin', 10]
users = [userA, userB]
print(userA)
print(userB)
print(users)
# a = users[1]
# print(a[0])
print(users[1][0])