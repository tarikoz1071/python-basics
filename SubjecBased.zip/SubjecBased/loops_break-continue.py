name = 'Taha Ozdogan'

for letter in name:
    if letter == 'h':
        continue
    elif letter == 'O':
        break
    print(letter)
x = 0
while x < 5:
    x+=1
    if x == 2:
        continue
    print(x)
    
# 1-100'e kadar tek sayilarin toplami
# teklist = []
a = 0
result = 0
while a < 100:
    a += 1
    if a % 2 == 0:
        continue
    result = result + a
    # teklist.append(a)
# print(teklist)