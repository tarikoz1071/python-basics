'''
    modul hakkinda bilgilendirme
'''
print('modul eklendi')

number = 11
numbers = [1,2,3]
person = {
    "name":"Abdurrahim",
    "age":"25",
    "city":"istanbul"
}


def func(x):
    '''
    Fonksiyon hakkinda bilgilendirme
    '''
    return f'x: {x}'


class Person:
    def speak(self):
        print('I am speaking...')
