def greeting(name):
    print('hello',name)
greeting('taha')

print(greeting)
# sayHello = greeting
# print(sayHello)
# del sayHello


# # ENCAPSULATION
# print('\n',' Encapsulation '.center(71,"*"))
# def outer(num1):
#     print('outer')
#     def inner_increment(num1):
#         return num1 + 2
#     num2 = inner_increment(num1)
#     print(num1,num2)
# outer(7)


# ============================================================================================
# print('\n',' Encapsulation-2 '.center(71,"*"))
# def factorial(number):
#     if not isinstance(number, int):
#         raise TypeError ("number must be an integer")
    
#     if not number >= 0:
#         raise ValueError("number must be zero or positive")

#     def inner_factorial(number):
#         if number <=1:
#             return 1
#         return number * inner_factorial(number - 1) 
#     return inner_factorial(number)
# number = input(f'Enter the number of which factorial is calculated: ')

# try:
#     print(f'The factorial of {number} is: {factorial(int(number))}')
# except Exception as ex:
#     print(ex)

# ============================================================================================
# def factorial(number):
#     if not isinstance(number, int):
#         raise TypeError ("number must be an integer")
    
#     if not number >= 0:
#         raise ValueError("number must be zero or positive")

#     def inner_factorial(number):
#         if number <=1:
#             return 1
#         return number * inner_factorial(number - 1) 
#     return inner_factorial(number)

# try:
#     print(factorial(7))
# except Exception as ex:
#     print(ex)
    