import re

def mark_calculator(x):
    x=x[:-1]
    list1=x.split(':')
    studentName = list1[0]
    studentMarks = list1[1].split(",")
    mark1 = int(studentMarks[0])
    mark2 = int(studentMarks[1])
    mark3 = int(studentMarks[2])
    avarageMark = (mark1+mark2+mark3)/3
    if avarageMark>=90 and avarageMark<=100:
        letter = 'AA'
    elif avarageMark>=85 and avarageMark<=89:
        letter = 'BA'
    elif avarageMark>=80 and avarageMark<=84:
        letter = 'BB'
    elif avarageMark>=75 and avarageMark<=79:
        letter = 'CB'
    elif avarageMark>=70 and avarageMark<=74:
        letter = 'CC'
    elif avarageMark>=65 and avarageMark<=69:
        letter = 'DC'
    elif avarageMark>=60 and avarageMark<=64:
        letter = 'DD'
    elif avarageMark>=50 and avarageMark<=59:
        letter = 'FD'
    elif avarageMark>0 and avarageMark<=49:
        letter = 'FF'
    return(studentName+': '+str(avarageMark)+' '+str(letter))


def read_marks():
    with open("C:/Users/trtozd/Desktop/python_temelleri/exam_marks.txt","r",encoding="utf- 8") as file:
        for line in file:
            print(mark_calculator(line))
    

def enter_mark():
    name = input('Student Name: ')
    surname = input('Student Surname: ')
    mark1 = input('mark 1:')
    mark2 = input('mark 2:')
    mark3 = input('mark 3:')
    with open("C:/Users/trtozd/Desktop/python_temelleri/exam_marks.txt","a",encoding="utf- 8") as file:
        file.write(name+' '+surname+':'+mark1+','+mark2+','+mark3+'\n')

def save_marks():
    with open("C:/Users/trtozd/Desktop/python_temelleri/exam_marks.txt","r",encoding="utf- 8") as file:
        list1 = []
        for i in file:
            list1.append(mark_calculator(i))
    with open("C:/Users/trtozd/Desktop/python_temelleri/exam_results.txt","w",encoding="utf- 8") as file2:
        for i in list1:
            file2.write(i+'\n')





while True:
    islem = input('1- Read Marks\n2- Enter Mark\n3- Save marks\n4- Exit\n')
    if islem == '1':
        read_marks()
    elif islem == '2':
        enter_mark()
    elif islem == '3':
        save_marks()
    else:
        break