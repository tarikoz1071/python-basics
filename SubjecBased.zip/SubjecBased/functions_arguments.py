
def changeName(n):      # Value type larda degiskenin farkli bir kopyasi fonksiyon icin hazirlanip bellekte tutulur.
    n = 'Murat'
name = 'Kamil'
changeName(name)
print(name,'\n')
'''--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
def change(n):     # Listelerde farkli olarak referans kopyalamasi var(n parametresine, sehirler dizisinin adresi gonderiliyor.)
    n[1]='istanbul'
sehirler1 = ['gumushane','costantiniyye']
print(sehirler1)
change(sehirler1)
print(sehirler1) 
'''--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
sehirler2 = ['gumushane','nigde']
n = sehirler2             # REFERENCING THE LIST's ADDRESS TO ANOTHER VARIABLE
print(sehirler2)          # PRINTING BEFORE CHANGE
n[0] = 'bayburt'         # CAHNGING THE REFERENCED ADRESS' OBJECT 
print(sehirler2)          # PRINTING AFTER CHANGE
'''--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
sehirler3 = ['sirnak','nigde']
print(sehirler3)
n = sehirler3[:]     #SLICING (COPYING THE VARIABLE INSTEAD OF ADDRESS REFERENCING)
n[1] = 'aksaray'
print(n)


'''============================================================================================================================================================================================================================================================================================'''


# Toplama islemi yapan bir fonksiyon
''' #def toplama (x, y, z=0, d=0, e=0):   
#    return sum(x,y,z,d,e)
'''
def toplama(*parametreler):     # tuple veya list icin tek yildiz.
    print(type(parametreler), end=' ')
    sum = 0
    for n in parametreler:
        sum = sum +n
    return(sum)
    #return sum(parametreler)       JUST AFTER THE "def" line
print(' ----------->  1.toplam: ', toplama(7,1))
print(' ----------->  2.toplam: ', toplama(5,3,3,1))
print(' ----------->  3.toplam: ', toplama(35,15,1,1,1,2,33,11,3,12,3),'\n')
'''--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
# Toplama islemi yapan bir fonksiyon
def displayUser(**args):        # iki yildiz dictionary alir tek yildiz ise liste/tuple.
    print(type(args))
    for key, value in args.items():
        print('{} is {}'.format(key, value), end= ' ')
displayUser(name = 'Murat', age=53, city = 'Bayburt')
displayUser(name = 'Hasan', age=53, city = 'Canakkale', phone = '123123')
displayUser(name = 'Recep', age=53, city = 'Balikesir',phone = '456789', mail='rectem@gmail.com')
print('\n')
'''--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'''
def myFunc(a,b,c,*args,**kerwargs):
    print (a)
    print (b)
    print (c)
    print (args)
    print (kerwargs)

myFunc(22,454,65,4,1,2,6,key1 = 'value1',key2 = 'value2')
print('\n')










# print ('\n\n')
# a = 3
# b = 3
# c = 257
# d = 257
# e = -5
# f = -5
# g = -6
# h = -6
# print (id((a)))
# print (id((b)))
# print (id((c)))
# print (id((d)))
# print (id((e)))
# print (id((f)))
# print (id((g)))
# print (id((h)))

