
liste = ["1","2","7c","123b","cxz","11","53"]


# 1- Liste elemanlari icindeki sayisal degerleri bulunuz.
updatedList = []
for x in liste:
    try:
        print(int(x), end=' ')
        updatedList.append(int(x))
    except ValueError:
        continue
print()
print(updatedList)
        

# 2- Kullanici 'q' degerini girmedikce aldiginiz her inpputun sayi
# oldugundan emin olunuz aksi halde hata mesaji yazin.
numList=[]
while True:
    number = input("Enter a number (Type 'q' to finish): ")
    if number == 'q':
        break
    try:
        numList.append(float(number))
        print('The number you entered: ',number)
    except ValueError:
        print(f"{number} is not accepted Please enter a number.")
        continue
print(numList)




# 3- Girilen parola icinde turkce karakter hatasi tanimlayiniz.

def checkPassword(password):
    turkce_karakterler = 'şçğüöıİ'

    for j in password:
        if j in turkce_karakterler:
            raise TypeError('The password cannot contain Turkish characters.')
        else:
            pass
    print('Valid password.')


for r in range(7):
    try:
        password = input('passowrd: ')
        checkPassword(password)
        break
    except TypeError as err:
        continue
        print(err)


# 4- Faktoriyel fonksiyonu olusturup fonksiyona gelen deger icin
# hata mesajlari verin.
from math import factorial


def fini(f):
    f = int(f)
    if f < 0:
        raise ValueError('Negative value!')
    result = 1
    for i in range(1, x+1):
        result *= i
    return result

for x in [5,10,21,-3,'13c']:
    try:
        y = fini(x)
    except ValueError as err:
        print(err)
        continue
    print(y)   








