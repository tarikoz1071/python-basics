
# YONTEM 1
import math
print(' YONTEM 1 '.center(50,'*'))
value1 = dir(math)
# value2 = help(math)
# value3 = help(math.factorial)
value4 = math.sqrt(49)
value5 = math.factorial(7)
value6 = math.floor(7.9)
value7 = math.ceil(7.9)
print(value4)
print(value5)
print(value6)
print(value7)



# YONTEM 2
import math as islem
print(' YONTEM 2 '.center(50,'*'))
deger = dir(islem)
deger1 = islem.factorial(7)
print(deger1)



# YONTEM 3
from math import *
print(' YONTEM 3 '.center(50,'*'))
sonuc = factorial(7)
sonuc1 = sqrt(9)
print(sonuc)
print(sonuc1)



# YONTEM 3
from math import factorial,sqrt
def sqrt(x):print('x: ' + str(x**(1/2)))        # Sonradan tanimlanan fonksiyon oncekini ezer.
print(' YONTEM 4 '.center(50,'*'))
sonucc1 = factorial(5)
sonucc2 = sqrt(49)
sonucc3 = ceil(9.3)
print(sonucc1)
print(sonucc2)
print(sonucc3)