
# 1- Girilen 2 sayidan hangisi buyuktur?
a = int(input('bir sayi giriniz: '))
b = int(input('ikinci sayiyi giriniz: '))
result1 = (a > b)
print (f'a: {a} b: {b} den buyuktur: {result1}')
                                                                                                                                    # if a > b: print(f"ilk girdiginiz {a} sayisi ikinci girmis oldugunuz {b} sayisindan buyuktur.")
                                                                                                                                    # elif a == b:print(f"ilk girdiginiz {a} sayisi ile ikinci girdiginiz {b} sayisi birbirine esittir.")
                                                                                                                                    # else:print(f"ikinci girdiginiz {b} sayisi ilk girmis oldugunuz {a} sayisindan buyuktur.")

# 2- Kullanicidan 2 vize (%60) ve final (%40) notunu alip ortalama hesaplayiniz.
#   Eger ortalama 50 ve ustundeyse gecti degilse kaldi yazdirin.
vize1,vize2,final = float(input("vize-1 notunuz: ")),float(input("vize-2 notunuz: ")),float(input("final notunuz: "))
ortalama = vize1*30/100 + vize2*30/100 + final*40/100   # ortalama =  (((vize1 + vize2)/2)*0.6) + (final * 0.4) 
print (f"Ortalamaniz = {ortalama} dersten gecme durumunuz: {ortalama >= 50 }")

                                                                                                                                    # if 50 <= ortalama <= 100:print ("Gecer not!")
                                                                                                                                    # elif 0 <= ortalama < 50:print ("Basarisiz!")
                                                                                                                                    # else:print ("Hatali not girdiniz!")

# 3- Girilen bir sayinin tek mi cift mi oldugunu yazdirin.
sayi = int(input('sayi giriniz: '))
tekcift = (sayi % 2 == 0)
print (f"Girilen sayinin cift olma durumu: {tekcift} ")
                                                                                                                                    # if tekcift % 2 == 0:print ("Cift sayi!")
                                                                                                                                    # elif tekcift % 2 != 0:print ("Tek sayi!")
                                                                                                                                    # else:print ("Hatali giris yaptiginiz icin sonuc bulunamadi!")

# 4- Girilen bir sayinin negatif pozitif durumunu yazdirin.
sayinegpoz = int(input('sayi giriniz: '))
pozitifmi = (sayinegpoz > 0)
print (f"Girilen sayinin poitif olma durumu: {pozitifmi} ")
                                                                                                                                    # if sayinegpoz >= 0: print ("pozitif sayi!")
                                                                                                                                    # elif sayinegpoz < 0:print ("negatif sayi!")
                                                                                                                                    # else:print ("Hatali giris yaptiginiz icin sonuc bulunamadi!")

# 5- Parola ve email bilgisini isteyip dogrulugunu kontrol ediniz.
#   (email: email@tahaozdogan.com parola:abc123)
email = 'email@tahaozdogan.com'
password = 'abc123'
girilenEmail = input('email: ')
girilenPassword = input('parola: ')
isEmail = (email == girilenEmail.strip())
isPassword = (password == girilenPassword.lower())
print (f"Email bilgisi dogrumu: {isEmail} ve parola dogru mu: {isPassword}")

                                                                                                # emailhesap = input("Email hesabinizi giriniz: ")
                                                                                                # if emailhesap.find('@',1,13) == False or emailhesap.rfind('.com') == False:print ("dogru adres giriniz!")
                                                                                                # elif emailhesap.find('@',1,13) ==  True and emailhesap.rfind('.com') == True:pass
                                                                                                # sifre = input("sifrenizi giriniz(sifrenizi girerken bir baskasinin gormediignden emin olunuz!).")
                                                                                                # print("Ek bilgi: sifernizde en az bir rakam bulunmalidir.")
                                                                                                # if sifre.find('1','2','3','4','5','6','7','8','9') == False:print ("dogru adres giriniz!")
                                                                                                # elif sifre.find('1','2','3','4','5','6','7','8','9') == True:pass














