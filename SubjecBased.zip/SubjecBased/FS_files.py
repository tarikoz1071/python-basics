# Dosya açmak ve oluşturmak için open() fonksiyonu kullanılır.
# Kullanımı: open(dosya_adi, dosya_erişme_modu)
# dosya_erişme_modu => dosyayı hangi amaçla açtığımızı belirtir.


# "w": (Write) yazma modu. 
#   **Dosyayi konumda olusturur. (Konum var olmali(Yeni klasor olusturmaz))
#   **Dosya icerigini siler ve yeniden ekleme yapar.
file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile.txt", "w", encoding = 'utf-8')
file.write("Taha Ozdogan\n")
file.close()


# "a": (Append) ekleme. Dosya konumda yoksa oluşturulur.
file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile.txt", "a", encoding = 'utf-8')
file.write("Ikram Ozdogan\n")
file.close()


# "x": (Create) oluşturma. Dosya konumda zaten varsa hata verir.
# file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile2.txt", "x", encoding = 'utf-8')


# "r": (Read) okuma. Varsayılan mod olup, Dosya konumda yoksa hata verir.

# "r+": (Read+) güncelleme. Dosya konumda yoksa hata verir ve içeriği düzenlemek için kullanılır.

