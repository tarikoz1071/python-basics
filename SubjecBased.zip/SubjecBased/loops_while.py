# 1-100 e kadar
x = 0
# while x < 100:
#     if x % 2 == 1:
#         print (f'sayi tek: {x}')
#     else:
#         print (f'sayi cift: {x}')
#     x = x + 1
# print ('Sayim bitti...')


name = '' # False
while not name.strip():
    name = input('isminizi giriniz: ')
print(f'merhaba {name}')