# class
'''
Class icerisinde attribute ve metod tanimlamalari yapabiliriz.
Attribute'lar hem "class" seviyesinde hem de "obje" seviyesinde yapilabilir.
Class > Methods >


Class > Attributes > class-level Att. > Obj-level Att. > constructor (yapici metod) > def __init__

Obje attribute'lar constructer (yapici metod) icerisinde metod(def) tanimlamasi seklinde tanimlanir.
Ornek: Asagida "__init__" metodu icerisinde bulunan  "self" parametresi class'tan turetilmis tum objeleri temsil eder.
"self" ile birlikte kullanmak istedigimiz attribute(ozellik) leri ise sonrasinda yazariz. name, year gibi.
def __init__ (self, name, year): 
    self.name = name
    self.year = year
Bu sekilde obje ilk olusturuldugunda mutlaka tanimlanmasini istediginiz ozellikleri object attribute'lar icerisinde olusturabilirsiniz.

Class attribute'lar ise kendisinin mensubu olan tum objeler icin calisir.

SONUC: Metod > attribute
'''
class Person:
    # class attributes
    addresi = 'no information'
    # constructor (yapici metod)
    def __init__(self, name, year):
        # object attributes
        self.adi = name
        self.yili = year
        print('init metodu calisti.')
        # methods


# object (instance)
p1 = Person(name = 'Hassan', year = 1977 )
p2 = Person('Ali', 1999)
# updating
p1.adi = 'Kamil'
p1.addresi = 'Kocaeli' 
# accessing object attributes
print(f'p1 name: {p1.adi} and year: {p1.yili} address: {p1.addresi}')
print(f'p2 name: {p2.adi} and year: {p2.yili} address: {p2.addresi}')

print(p1)
print(p2)
print(type(p1))
print(type(p2))
print(p1 == p2)
