# x = 10
# if x > 5:
#     raise Exception("x 5 ten buyuk deger alamaz.")

def check_password(psw):
    import re
    if len(psw) < 7:
        raise Exception("Parola en az 7 karakter olmalidir.")
    elif not re.search("[a-z]",psw):
        raise Exception ("Parola kucuk harf icermelidir.")
    elif not re.search("[A-Z]",psw):
        raise Exception ("Parola buyuk harf icermelidir.")
    elif not re.search("[0-9]",psw):
        raise Exception ("Parola rakam icermelidir.")
    elif not re.search("[!._@$]",psw):
        raise Exception ("Parola alpha numeric karakter icermelidir.")
    elif re.search("\s",psw):
        raise Exception("Parola bosluk icermemelidir.")
    else:
        print("gecerli parola")
# while True:
#     try:
#         print(f'\n\n','PAROLA OLUSTURMA EKRANI'.center(50,'*'))
#         password = str(input('Parola belirleyiniz: '))
#         check_password(password)
#     except Exception as ex:
#         print(ex)
#     else:
#         print("gecerli parola")
#         break
password = "123456"
password = "1234567"
password = "1234567a"
password = "1234567aA"
password = "1234567aA !"
password = "1234567aA!"

try: check_password(password)
except Exception as ex: print(ex)
else: print("gecerli parola: else")
finally: print('Try-Except sonlandi.')



class Person:
    def __init__(self, name, year):
        if len(name)>10:
            raise Exception ("name alani fazla karakter iceriyor.")
        else:
            self.name = name
p = Person("SadikAhmetDemirci",1997)














