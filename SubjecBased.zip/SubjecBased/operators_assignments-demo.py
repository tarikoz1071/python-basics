x, y, z = 2, 5, 107

numbers = 1, 5, 7, 10, 6

# 1- Kullanicidan aldiginiz 2 sayinin carpimi ile x,y,z toplaminin farki nedir?
# 2- y' nin x'e kalansiz bolumunu hesaplayiniz.
# 3- (x,y,z) toplaminin mod 3'u nedir?
# 4- y'nin x. kuvvetini hesaplayiniz.
# 5- x, *y, z = numbers islemine gore z'nin kupu kactir?
# 6- x, *y, z = numbers islemine gore y'nin degerleri toplami kactir?

a = input (f"lutfen birinci sayiyi giriniz: ")
b = input (f"lutfen ikinci sayiyi giriniz: ")
result1 = int(a)*int(b) - (x+y+z)

result2 = y // x

result3 = (x+y+z) % 3 

result4 = y**x

x, *y, z = numbers 
result5 = z**3              #216

result6 = y[0] + y[1] + y[2]

print (result1)
print (result2)
print (result3)
print (result4)
print (result5)
print (result6)