# x = input('1 sayi: ')
# y = input('2.sayi: ')

# print(type(x))
# print(type(y))

# toplam = int(x) + int(y)
# print(type(toplam))

# print(toplam)

x = 5           #int
y = 2.5         #float
name = 'Cinar'  #str
isOnline = True #bool

# print(type(x))
# print(type(y))
# print(type(name))
# print(type(isOnline))

#TYPE CONVERSION

#int to float
# x=float(x)
# print(x)
# print(type(x))

#float to int
# y=int(y)
# print(y)
# print(type(y))

#int\float to str
# result = str(x)+str(y)
# print(result)
# print(type(result))

#bool to str
# isOnline = str(isOnline)
# print(isOnline)
# print(type(isOnline))

#bool to int
# isOnline=False
# isOnline=int(isOnline)
# print(isOnline)
# print(type(isOnline))



