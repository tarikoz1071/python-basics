def my_decorator(func):
    def wrapper():
        print("Operations before the function")
        func()
        print("Operations after the function")
    return wrapper

@my_decorator
def sayHello():
    print('hello')
sayHello()
# OR 
# sayHello = my_decorator(sayHello)
# sayHello()

print()
print('BOSLUK'.center(55,'='))
print()

def my_decorator(func):
    def wrapper(name):
        print("Operations before the function")
        func(name)
        print("Operations after the function")
    return wrapper

@my_decorator
def sayHello(name):
    print('hello',name)
sayHello("Tahsin")



import math
import time

def calculate_time(func):
    def inner(*args,**kwargs):
        start = time.time()
        time.sleep(1)
        func(*args,**kwargs)
        finish = time.time()
        print("function "+ func.__name__ + " took " + str(finish-start)+ " seconds.")
    return inner


@calculate_time
def getpower(a,b):
    print(math.pow(a,b))


@calculate_time
def factorial(num):
    print(math.factorial(num))

@calculate_time
def addition(a,b):
    print(a+b)

getpower(3,5)
factorial(5)
addition(10,11)