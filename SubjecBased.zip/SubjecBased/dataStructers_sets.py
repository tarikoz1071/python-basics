setfruits = {'orange', 'apple', 'banana'}          # "set" dizileri, sirasi her defasinda rastgele olan listelerdir.
# print(fruits[0]) indekslenemez
print(setfruits)

# for x in setfruits:
#     print(x)

setfruits.add('cherry')                         # bir eleman ekleyebilir.
print(setfruits)                       
setfruits.update(['mango','pineapple'])
print(setfruits)

# myList = [1,2,5,5,4,4,2,1]
# print(myList)
# print(set(myList))

setfruits.remove('orange')
setfruits.discard('apple')
setfruits.pop()

print(setfruits)

setfruits.clear()
print(setfruits)