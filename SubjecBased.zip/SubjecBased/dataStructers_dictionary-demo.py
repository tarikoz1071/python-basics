'''
ogrenciler = {
    '120' : {
        'ad' : 'Tamer',
        'soyad' : 'gozupekogullari',
        'telefon' : '532 000 00 01'
    },
    '121' : {
        'ad' : 'kamer',
        'soyad' : 'aklipekogullari',
        'telefon' : '532 000 00 02'
    },
    '123' : {
        'ad' : 'sami',
        'soyad' : 'canipekogullari',
        'telefon' : '532 000 00 03'
    }
}

1- Bilgileri verilen ogrencileri kullanicidan aldiginiz bilgilerle
 dictionary icinde saklayiniz.

2- Ogrenci numarasini kullanicidan alip ilgili ogrenci bilgisini
gosterin.
'''

ogrencidictionary = {}              # carpi 3 yaparsan 3 ogrenci girdirirsin.
number = input("ogrenci no:")
name = input("ogrenci adi:")
surname = input("ogrenci soyadi:")
phone = input("ogrenci telefon:")
# ogrencidictionary[number] = {
#     'ad' : name,
#     'soyad': surname,
#     'telefon': phone
# }
ogrencidictionary.update({  # can be entered keys more than one
    number: {
        'ad': name,
        'soyad' : surname,
        'telefon' : phone
    }
})
number = input("ogrenci no:")
name = input("ogrenci adi:")
surname = input("ogrenci soyadi:")
phone = input("ogrenci telefon:")
ogrencidictionary.update({  
    number: {
        'ad': name,
        'soyad' : surname,
        'telefon' : phone
    }
})
number = input("ogrenci no:")
name = input("ogrenci adi:")
surname = input("ogrenci soyadi:")
phone = input("ogrenci telefon:")
ogrencidictionary.update({  
    number: {
        'ad': name,
        'soyad' : surname,
        'telefon' : phone
    }
})
# 2. sorunun cevabi
print('*'*50)
ogrNo = input('ogrenci no: ')
print(ogrencidictionary[ogrNo])
# ogrenci = ogrencidictionary[ogrNo]

print(f"Aradiginiz {ogrNo} nolu ogrencinin ad soyadi: {ogrencidictionary[ogrNo]['ad']} {ogrencidictionary[ogrNo]['soyad']}\ntelefon numarasi ise: {ogrencidictionary[ogrNo]['telefon']} gibidir.")

# number = input (f'Simdi siz buraya ogrenci no gireceksiiz: ', ogrencidictionary[ogrNo], 
#     'ondan sonra ad gireceksiiz: ', {ogrenciad}, 
#     'hele sonra soyadini: '{ogrencisoyad},
#     'hele en sonda telefonunu: ' {ogrencitel})
