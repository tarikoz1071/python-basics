


def addition(a,b):return a+b
def substraction(a,b):return a-b
def multiplication(a,b):return a*b
def division(a,b):return a/b

def operation(f1,f2,f3,f4,operation_name):
    if operation_name == 'addition':print(f1(2,3))
    elif operation_name == 'substraction':print(f2(5,3))
    elif operation_name == 'multiplication':print(f3(7,5))
    elif operation_name == 'division':print(f4(100,13))
    else:
        print('invalid operation')

operation(addition,substraction,multiplication,division,'substraction')
# operation(substraction,addition,multiplication,division,'substraction')



