file = open("C:/Users/trtozd/Desktop/python_temelleri/newfile.txt", "r", encoding = 'utf-8')
content = file.read()
print(content)
file.close()


# Her seferinde dosyayi kapatmak mecburiyetindeyiz. Bunu isimiz bittiginde otomatik olarak yapmak
# icin "with" fonksiyonunu kullaniriz.
with open("newfile.txt","r","utf-8") as file:
    content = file.read()
    print(content)
    print(file.tell())
    content2 = file.read(10)
    print(content2)
