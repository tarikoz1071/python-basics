username = 'tahaozdogan'
password = '1234'

#isLoggedin = (username == 'tahaozdogan') and (password == '1234')

if (username == 'tahaozdogan') and (password == '1234') :
    print ('Hos geldiniz')
else:
    print('username ya da parola yanlis')
# ==================================================================================
if (username == 'tahaozdogan'):
    if (password == '1234'):
        print ('Hos geldiniz')
    else:
        print('parola yanlis')
else:
    print('username yanlis')