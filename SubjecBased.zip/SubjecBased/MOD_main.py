import MOD_mod          # Ayni dizinde oldugu icin alabildi. Fakat Python lib klasorunde veya "python, import sys and sys.path" komutlarinin ciktisindaki dizinlerde olan baska .py uzantili dosyalara da erisebilir.
                        # DLL klasorundekiler C dilinde yazilmis olup daha hizli calisirlar. "sys.builtin_module_names" komut ciktisinda bu kutuphanelerin isimlerini gorebilirsiniz.
# result = help(MOD_mod)
# result1 = help(MOD_mod.func)
result2 = MOD_mod.number
result3 = MOD_mod.numbers
result4 = MOD_mod.person["name"]
result5 = MOD_mod.person["age"]
result6 = MOD_mod.func(11)

p = MOD_mod.Person()
p.speak()


# print(result)
# print(result1)
print(result2)
print(result3)
print(result4)
print(result5)
print(result6)



