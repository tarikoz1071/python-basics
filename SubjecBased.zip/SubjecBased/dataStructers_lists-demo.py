from time import sleep


stringarabalar= 'BMW Mercedes Opel Mazda'

# 1- "BMW, Mercedes, Opel, Mazda" elemanlarina sahip bir liste olusturunuz.
result1 = 'BMW Mercedes Opel Mazda'.split(' ')
#-----------------------------------------------------alternative-method-----------------------------------------------------
arabalar = ['BMW', 'Mercedes', 'Opel', 'Mazda']




# 2- Liste kac elemanlidir?
result2 = len(result1)
#-----------------------------------------------------alternative-method-----------------------------------------------------
result = len(arabalar)




# 3- Listenin ilk ve son elemani nedir?
result3 = 'ilk eleman:' + str(result1[0]) + ' son eleman:' + str(result1[(result2-1)])
#-----------------------------------------------------alternative-method-----------------------------------------------------
result = 'Ilk eleman:'+ str(arabalar[0]) + ' Son eleman:' + str(arabalar[result-1])




# 4- Mazda degerini Toyota ile degistirin.
result4 = stringarabalar[:].replace('Mazda','Toyota').split()
#-----------------------------------------------------alternative-method-----------------------------------------------------
result04 = ['BMW', 'Mercedes', 'Opel', 'Mazda']
for i in range(len(result04)):
    if result04[i] == 'Mazda':
        result04[i] = 'Toyota'
                    # result = stringarabalar.replace('Mazda','Toyota')
#-----------------------------------------------------alternative-method-----------------------------------------------------
arabalar[-1]='Toyota'
result = arabalar[:]




# 5- Mercedes listenin bir elemani midir?
result5 = stringarabalar.index('Mercedes')
if result5 > 1:
    result5 = True
#-----------------------------------------------------alternative-method-----------------------------------------------------
result05 = ['BMW', 'Mercedes', 'Opel', 'Mazda']
for i in range(len(result05)):
    if result05[i] == 'Mercedes':
        result05 = ('Mercedes is an item of this list')
#-----------------------------------------------------alternative-method-----------------------------------------------------
result = 'Mercedes' in arabalar




# 6- Listenin -2 indeksindeki deger nedir?
result6 = arabalar[-2]
# 7- Listenin ilk 3 elemanini alin.
result7 = arabalar[0:3]




# 8- Listenin son 2 elemani yerine "Toyota" ve "Renault" degerlerini ekleyin. *(Assignment statements in Python do not copy objects, they create bindings between a target and an object.). --> https://stackoverflow.com/questions/21983014/why-does-values-of-both-variable-change-in-python
result8 = arabalar[:]
result8[-2:] = 'Toyota', 'Renault' 
#-----------------------------------------------------alternative-method-----------------------------------------------------
result = arabalar[:]
result[-2:] = ['Toyota', 'Renault']


# 9- Listenin uzerine "Audi" ve "Nissan" degerlerini ekleyin.
result9 = arabalar[:]
result9.extend(('Audi','Nissan'))
#-----------------------------------------------------alternative-method-----------------------------------------------------
result = arabalar[:] + ['Audi', 'Nissan']


# 10- Listenin son elemanini silin.
result10 = arabalar[:]
del result10[-1] 



# 11- Liste elemanlarini tersten yazdiriniz. Sondaki rakam adim araligidir.
result11 = result1[result2::-1]




# 12- Asagidaki verileri bir liste icinde saklayiniz.
    # studentA: Yasin Ikram 2010, (75,85,95)
    # studentB: Taha Ozdogan 1997, (77,83,93)
    # studentC: Mehmet Ozdogan 1996, (57,93,95)
studentA = ['Yasin', 'Ozdogan', 2010, [75,85,95]]
studentB = ['T. Taha', 'Ozdogan', 1997, [77,83,93]]
studentC = ['Mehmet F.', 'Ozdogan', 1996, [57,93,95]]
# result12 = [studentA,studentB,studentC]



# 13- Liste elemanlarini ekrana yazdiriniz.
result13 = studentA[0]
result13 = studentB[1] 
result13 = studentC[3][1]

result13 = f"{studentA[0]} {studentA[1]} {2022-studentA[2]} yasinda ve not ortalamasi {(studentA[3][0] + studentA[3][1] + studentA[3][2])/3}"

resslist = [result1, result2, result3, result4, result5, result6, result7, result8, result9, result10, result11, result13]
cevaplist = ['cevap-1: ', 'cevap-2: ', 'cevap-3: ', 'cevap-4: ', 'cevap-5: ', 'cevap-6: ', 'cevap-7: ', 'cevap-8: ', 'cevap-9: ', 'cevap-10: ', 'cevap-11: ', 'cevap-12: ', 'cevap-13: ']

for i,j in zip (resslist, cevaplist):
    print (j)
    print (i)
    sleep (0.03)

# print(result1)
# print(result2)
# print(result3)
# print(result4)
# print(result04)
# print(result5)
# print(result05)
# print(result6)
# print(result7)
# print(arabalar)
# print(result8)
# print(result9)
# print(result10)
# print(result11)
# print(result12)
# print(result13)
# print(result)