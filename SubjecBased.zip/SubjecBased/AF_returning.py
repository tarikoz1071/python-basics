def usalma(number):
    def inner (power):
        return number ** power
    return inner 

two = usalma(2)
print(two(9))
# a = two(9)
# print(a)


def auth_query(page):
    def inner(role):
        if role == 'Admin':
            return "{0} rolu {1} sayfasina ulasabilir".format(role,page)
        else:
            return"{0} rolu {1} sayfasina ulasamaz".format(role,page)
    return inner

user = auth_query("Service Portfolio")
print(user("Admin"))
print(user("user"))



def operation(operation_name):
    
    def addition(*args):
        sum = 0
        for i in args:
            sum = sum+i
        return sum

    def multiplication(*args):
        mux = 1
        for i in args:
            mux = mux*i
        return mux
    
    if operation_name == "addition":
        return addition
    else:
        return multiplication

adding = operation("addition")
print(adding(1,3,5,7,9,11,13,15,17,19,21,23,25,27,29,31,33,35,37,39,41))

multiplexing = operation("multiplication")
print(multiplexing(1,3,5,7,9,11))
