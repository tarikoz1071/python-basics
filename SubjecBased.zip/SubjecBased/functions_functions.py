''''
"def" define'in kisaltilmisidir.
Ekrana printi yazmak yerine biz fonksiyona disaridan bir bilgi gonderelim ve bizim icin
string bir ifade olustursun ve bunu bana geriye gondersin (degiskenin icine)
'''


def sayHello(name = 'USER'):        # varsayilan deger tanimlamasi.
    print('Hello ' + name)

sayHello('Murat')
sayHello('Ikram')
sayHello('Taha')
sayHello()
print ('')

def sayHello(name = 'USER'):        # varsayilan deger tanimlamasi.
    return 'Hello ' + name.strip()
mesaj = sayHello('Murat')
print (mesaj)

def total(num1, num2):
    return num1 + num2
result = total(10,15)
print(result)


def yasHesapla(dogumYili):
    return 2023 - dogumYili

ageTaha = yasHesapla(1997)
ageMurat = yasHesapla(1970)
ageIkram = yasHesapla(2010)
print(ageMurat,ageTaha,ageMurat)

def emekliligeKacYilKaldi(dogumYili,isim):
    '''
    DOCSTRING: Dogum yiliniza gore emekliliginize kac yil kaldi
    INPUT: Dogum yili
    OUTPUT: Hesaplanan yil bilgisi
    '''
    yas = yasHesapla(dogumYili)
    emeklilik = 65 - yas
    if emeklilik > 0:print(f'Merhaba {isim}, emekliliginize {emeklilik} yil kaldi.')
    else:print(f'Merhaba {isim}, zaten emekli oldunuz.')
emekliligeKacYilKaldi(1983,'Yasar')
emekliligeKacYilKaldi(1950,'Mehmet')
emekliligeKacYilKaldi(1974,'Hasan')

print(help(emekliligeKacYilKaldi))
list = [1,2,3,4]
print(help(list.append))