'''
    Daire Alani     : pir2
    Daire Cevresi   : 2pir

    *Yari capi verilen bir dairenin alan ve cevresini hesaplayiniz. (r: 3.14)
'''

pi = 3.14
r = float(input("yari cap: "))
#r = float(r)
alan = pi* r ** 2
cevre = 2 * pi * r 
print("alan: "+ str(alan) + " cevre: "+ str(cevre))