# 1- Kullanicidan isim, yas ve egitim bilgilerini isteyip ehliyet alabilme 
# durumunu kontrol ediniz. Ehliyet alma kosulu en az 18 ve egitim durumu
# lise ya da universite olmalidir.
a,b,c = input('isminiz: '), int(input('yasiniz: ')), input('egitim bilginiz(universite/lise/orta/ilkokul): ')
if (b >= 18):
    if (c=='lise' or c=='universite'):
        print(f'{a} kisisi ehliyet alabilir.')
    else:
        print(f'{a} kisisi ehliyet alamaz zira egitim durumu yetesiz.')
else:
    print(f'{a} kisisi ehliyet alamaz cunku yasi tutmuyor.')

#elif (b < 18) or not (c=='lise' or c=='universite'):
#   print(f'{a} kisisi ehliyet alamaz cunku yasi tutmuyor.')

# 2- Bir ogrencinin 2 yazili bir sozlu notunu alip hesaplanan ortalamaya gore
#   not araligina karsilik gelen not bilgisini yazdiriniz.
#   0 - 24 => 0
#   25 - 44 => 1
#   45 - 54 => 2
#   55 - 69 => 3
#   70 - 84 => 4
#   85 - 100 => 5 
yazili1,yazili2,sozlu = float(input('ilk yazili notu: ')), float(input('ikinci yazili notu: ')), float(input('sozlu notu: '))
ortalama = (yazili1 + yazili2 + sozlu) / 3
if (0 <= ortalama) and (ortalama < 25):
    print(f'ortalamaniz: {ortalama} ve notunuz 0 dir.')
elif (25 <= ortalama) and (ortalama < 45):
    print(f'ortalamaniz: {ortalama} ve notunuz 1 dir.')
elif (45 <= ortalama) and (ortalama < 55):
    print(f'ortalamaniz: {ortalama} ve notunuz 2 dir.')
elif (55 <= ortalama) and (ortalama < 70):
    print(f'ortalamaniz: {ortalama} ve notunuz 3 dir.')
elif (70 <= ortalama) and (ortalama < 85):
    print(f'ortalamaniz: {ortalama} ve notunuz 4 dir.')
elif (85 <= ortalama) and (ortalama <= 100):
    print(f'ortalamaniz: {ortalama} ve notunuz 5 dir.')
else:
    print(f'{ortalama} hatali bilgi girdiniz lutfen tekrar deneyin.')



# 3- Trafige cikis tarihi alinan bir aracin servis zamanini asagidaki bilgilere
#   gore hesaplayiniz.
#   1. Bakim => 1. yil
#   2. Bakim => 2. yil
#   3. Bakim => 3. yil
#   ** Sure hesabini alinan gun, ay, yil bilgisine gore gun bazli hesaplayiniz.
#   *** datetime modulunu kullanmaniz gerekiyor.
import datetime
tarih = input('araciniz hangi tarihte trafige cikti? (orn 2019/8/9): ')
tarih = tarih.split('/')
trafigeCikis = datetime.datetime(int(tarih[0]),int(tarih[1]),int(tarih[2]))
simdi = datetime.datetime.now()
fark = simdi - trafigeCikis
days = fark.days 
#days = int(input('araciniz kac gundur trafikte: '))
if (days<365):
    print('aracinizin 1.bakim yili icerisindesiniz.')
elif (days>365)and (days<365*2):
    print('aracinizin 2.bakim yili icerisindesiniz.')
elif (days>365*2)and (days<365*3):
    print('aracinizin 3.bakim yili icerisindesiniz.')
else:
    print('hatali sure')


#dateentry = input('Aracinizin trafige cikis tarihini yil,ay,gun seklinde yaziniz (orn: 2019/11/20): ')
#year, month, day = map(int, dateentry.split(','))
#date = datetime(year, month, day)
#print (date)

# STACK OVERFLOW
# dates in string format
#str_d1 = date
#str_d2 = datetime.now()
# convert string to date object
#d1 = datetime.strptime(str_d1, "%Y/%m/%d")
#d2 = datetime.strptime(str_d2, "%Y/%m/%d")
# difference between dates in timedelta
#delta = d2 - d1
#print(f'Difference is {delta.days} days')

# CHAT GPT
# from datetime import datetime, timedelta
# Get the current date and time
# now = datetime.now()
# Get the input date
# input_date = input("Enter a date (YYYY-MM-DD): ")
# Convert the input date to a datetime object
# input_datetime = datetime.strptime(input_date, "%Y-%m-%d")
# Calculate the difference between the current date and the input date
# difference = now - input_datetime
# Print the difference
# print(difference)
# days = difference.days
# print(days)

